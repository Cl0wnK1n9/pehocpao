# run this script with bin/bash
# This script will build the docker image and run the container

docker build -t isactf-bofandfmts .
docker run -p 9003:9003 isactf-bofandfmts 