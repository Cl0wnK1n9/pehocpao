#include <stdio.h>
#include <string.h>

void vuln() {
    char role[6]  = "GUEST";
    char secure[14] = "REACTED";
    char buf[100];
    
    gets(buf);

    if(strstr(secure,"REACTED") != NULL){
    // if username is admin, print the flag
        if (strcmp(role, "ADMIN") == 0) {
            printf("Flag: EagleEyeCTF{FAKE_FLAG}\n");
        } else {
            // format string vulnerability start with string "Hello, "
            printf("Hello, ");
            printf(buf);
        }
    }
    else{
        printf("Yo Hacker are not allowed!!!!!! Go away\n");
    }
}

int main(int argc, char **argv) {

    printf("Welcome to the vulnerable program!\n");
    printf("Enter your username: ");
    vuln();
}

