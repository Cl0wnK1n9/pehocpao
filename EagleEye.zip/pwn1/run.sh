# run this script with bin/bash
# This script will build the docker image and run the container

docker build -t isactf-cardgame .
docker run -d -p 9001:9001 isactf-cardgame 