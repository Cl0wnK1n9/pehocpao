#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <stdbool.h>
#include <time.h>




// function to mix the cards
void mixCards(char *cards) {
    for (int i = 0; i < 13; i++) {
        int j = rand() % 13;
        char temp = cards[i];
        cards[i] = cards[j];
        cards[j] = temp;
    }
}

void checkCard(char card){
    if (card == 'A') {
        printf("YAY! You got the Ace and Win this game!\n");
    } else {
        printf("WHOOPS! You got the %c and lose this game!\n", card);
    }
}

void pickCard(char *cards) {
    int pos;
    printf("Pick a card at: ");
    scanf("%d", &pos);
    while (getchar() != '\n');
    printf("You picked: %c\n", cards[pos]);
    checkCard(cards[pos]);
    
}

int main() {
    setbuf(stdout, NULL);
    

    bool cont = true;
    char action;
    char cardBuf[13] = {'A','1','2','3','4','5','6','7','8','9','J','Q','K'};
    char secret[26] = "EagleEyeCTF{P00fItsMagic}";

    printf("[+] INITIALIZING GAME...  \n\n");
    sleep(1);
    printf("[+] GAME RULE\n");
    printf("1. You will pick a card from the deck\n");
    printf("2. If you get the Ace, you win the game\n");
    printf("3. If you get other cards, you lose the game\n");
    printf("4. You can play the game as many times as you want\n");
    printf("5. Have fun!\n\n");
    sleep(2);
    printf("[+] GAME STARTED!\n\n");
    srand(time(NULL));
    mixCards(cardBuf);
    pickCard(cardBuf);

    
    while (cont){
        printf("Do you want to play again? (y/n): ");
        action = getchar();
        while (getchar() != '\n');

        if (action == 'y' || action == 'Y') {
            cont = true;
            mixCards(cardBuf);
            pickCard(cardBuf);
        }
        else if (action == 'n' || action == 'N')
        {
            printf("Thank you for playing!\n");
            cont = false;
        }
        else {
            printf("Invalid input!\n");
            cont = true;
        }
    }
    
}