# run this script with bin/bash
# This script will build the docker image and run the container

docker build -t demo .
docker run -d -p 9006:80 demo 