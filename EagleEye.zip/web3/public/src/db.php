<?php   

function login($username, $password) {
    $db = new SQLite3('db.sqlite', SQLITE3_OPEN_READONLY);
    $result = $db->query("SELECT * FROM users WHERE username = '" . $username . "' AND password = '" . $password . "'");
    $row = $result->fetchArray();
    $db->close();
    // return first row
    return $row;
}

// Get password from environment variable
$password = getenv('FLAG');
// check if db.sqlite exists
if (!file_exists('db.sqlite')) {
    $db = new SQLite3('db.sqlite', SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);
    $db->exec('CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)');
    $db->exec('INSERT INTO users (username, password) VALUES ("admin", "' . $password . '")');
    $db->close();
}

?>