<?php
    function sqliShield($input){
        return str_replace("'", "''", $input);
    }

    function Validate($input){
        if (is_array($input)){
            $size = count($input);
            for ($i = 0; $i < $size; $i++){
                $input[$i] = sqliShield($input[$i]);
            }
            return implode(" ",$input);
        }
        else{
            return sqliShield($input);
        }
    }
?>