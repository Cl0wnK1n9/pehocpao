<?php
include_once("db.php");
include_once("render.php");
include_once("security.php");




session_start();

if (isset($_SESSION['username'])){
    header("Location: index.php");
    exit();
}
if (isset($_POST["username"]) && isset($_POST["password"])){
    $username = $_POST["username"];
    $password = $_POST["password"];
    $result = login(validate($username), validate($password));
    // $result = login($username, $password);
    session_regenerate_id(true);
    if ($result){
        $_SESSION["username"] = $result["username"];
        header("Location: index.php");
        exit();
    }
    else{
        echo render("login.html");
    }
}
else{
    echo render("login.html");
}


?>