<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }
    else {
        echo "<a href='logout.php'>Logout</a>";
        echo "<h1>Welcome back, " . htmlspecialchars($_SESSION['username']) . "!</h1>";
        echo "But or site is still under construction. Please check back later.";
    }

?>