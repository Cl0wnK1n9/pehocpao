<?php
    function render($file){
        return file_get_contents("templates/$file");
    }
?>