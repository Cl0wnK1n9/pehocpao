#include <stdio.h>
#include <string.h>

void vuln() {
    char role[6]  = "GUEST";
    char buf[100];
    
    // get username from user input with gets
    gets(buf);
    // if username is admin, print the flag
    if (strcmp(role, "ADMIN") == 0) {
        printf("Flag: EagleEyeCTF{Nu0c_Tr@n_Bo_deeeeeee}\n");
    } else {
        printf("Hello, %s!\n", buf);
    }
}

int main(int argc, char **argv) {

    printf("Welcome to the vulnerable program!\n");
    printf("Enter your username: ");
    vuln();
}

