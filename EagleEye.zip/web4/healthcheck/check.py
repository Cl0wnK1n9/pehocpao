import asyncio
import websockets
import random

async def send_ws_request():
    random.seed("Cl0wnK1n9_ultimate_secret_seed")
    uri = "ws://192.168.79.128:4444"  # Replace with your WebSocket server URL
    async with websockets.connect(uri) as websocket:
        # Send a message
        await websocket.send("/buyLotto 1 2 3 4")
        print("Message sent to the server.")
        # Receive a message
        response = await websocket.recv()
        print(f"Response from server: {response}")
        times = response.split(" ")[-5]
        times = int(times)
        lastWinningNumbers = response.split(" ")[-11:-7]
        lastWinningNumber = [i.replace('[','').replace(']','').replace(',','') for i in lastWinningNumbers]
        print(f"Times: {times}")
        print(f"Last winning number: {lastWinningNumber}")
        tmp = []
        lottle = ""
        for _ in range(times):
            tmp.append (random.randint(1, 99))
        print(tmp)
        print(len(tmp))
        if tmp[-4::] == lastWinningNumber:
            for _ in range(4):
                lottle+= str((random.randint(1, 99))) + " "
            lottle = "/buyLotto "+lottle
            await websocket.send(lottle)
            print(f"Message sent to the server: {lottle}")
            response = await websocket.recv()
            print(f"Response from server: {response}")
        else:
            print("wrong seed")

# Run the WebSocket client
asyncio.run(send_ws_request())
