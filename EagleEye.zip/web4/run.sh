# run this script with bin/bash
# This script will build the docker image and run the container

docker build -t babyweb .
docker run -d -p 4444:4444 -p 9007:8080 babyweb 