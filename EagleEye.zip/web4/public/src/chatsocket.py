import asyncio
import websockets
import random
import string
import os

FLAG = os.getenv("FLAG", "fake_flag")
count = 0

def random_pincode():
    lottery = []
    # random integer from 1 to 99
    for _ in range(4):
        lottery.append(random.randint(1, 9999))
    return lottery

# WebSocket server setup
connected_clients = set()

async def handle_client(websocket):
    global count
    try:
        while True:
            message = await websocket.recv()  # Waits for a message from the client
            print(f"Received message from client: {message}")
            # if message start with /flag
            userMessage = message.split(" ")
            userLotto = []
            if (userMessage[0] == "/buyLotto"):
                for i in userMessage[1:]:
                    if not i.isdigit():
                        await websocket.send("Invalid input. Please enter 4 numbers separated by spaces.")
                        continue
                    else:
                        userLotto.append(int(i))
                if len(userLotto) != 4:
                    await websocket.send("Invalid input. Please enter 4 numbers separated by spaces.")
                    continue
                count += 4
                lotteries = random_pincode()    # Generate a new secret pincode
                for lottery in lotteries:
                    if lottery not in userLotto:
                        await websocket.send(f"Sorry, you didn't win the lottery. The winning number is {lotteries}, there are {count} lotteries have been sold.")
                        break
                    await websocket.send(f"Congratulations! Here is your flag: {FLAG}")
                    break
            else:
                await websocket.send(f"Received message: {message}")

    except websockets.ConnectionClosed:
        print("Client disconnected.")

async def start_websocket_server():
    async with websockets.serve(handle_client, "0.0.0.0", 4444):
        print("WebSocket server running on ws://localhost:1234")
        await asyncio.Future()  # Keeps the WebSocket server running

# Function to start the WebSocket server in a child process
def run_websocket_server():
    # create seed for random
    random.seed("fhjioqhpweikfjasldkfmnioqwj")
    asyncio.run(start_websocket_server())

if __name__ == "__main__":
    run_websocket_server()

