# sqlite3 is used to store the username and password
import sqlite3
import os

def Init():
    admin_pass = os.getenv('ADMIN_PASS',"admin")
    # create a database have a table with ID, username, password which ID is primary key
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    # if the table is exist, drop it
    c.execute('''DROP TABLE IF EXISTS users''')
    conn.commit()
    # create a table with ID, username, password
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)''')
    conn.commit()
    
    # insert a default user
    c.execute("INSERT INTO users (username, password) VALUES ('admin', '"+admin_pass+"')") 
    conn.commit()

    # drop the table if it is exist
    c.execute('''DROP TABLE IF EXISTS notes''')
    # create note table which have userId, key, note id linked to the userID at users table
    c.execute('''CREATE TABLE IF NOT EXISTS notes (userId INTEGER, title TEXT, key TEXT, note TEXT)''')
    conn.commit()
    # insert a default note which key is on environment variable
    key = os.getenv('FLAG', 'EagleEye{FAKE_FLAG}')
    c.execute("INSERT INTO notes (userId, title, key, note) VALUES (1, 'secret note', '"+key+"', 'GoodJob')")
    conn.commit()

    conn.close()



def Authentication(username, password):
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''SELECT * FROM users WHERE username = ? AND password = ?''', (username, password))
    result = c.fetchone()
    conn.close()
    if result:
        return True
    return False

def Register(username, password):
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''SELECT * FROM users WHERE username = ?''', (username,))
    result = c.fetchone()
    if result:
        return False
    c.execute('''INSERT INTO users (username, password) VALUES (?, ?)''', (username, password))
    conn.commit()
    conn.close()
    return True
