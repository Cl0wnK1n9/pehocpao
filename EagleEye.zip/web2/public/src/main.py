# simple flask app
from flask import Flask, render_template, request, redirect, url_for, session
import auth
import note
import bot
import os

hostname = os.getenv('HOSTNAME', '127.0.0.1')


auth.Init()

app = Flask(__name__)
# set the secret key.  keep this really secret:
app.secret_key = 'REACTED'

@app.route('/', methods=['GET'])
def home():
    return redirect(url_for('index'))

@app.route('/home', methods=['GET'])
def index():
    if 'username' in session:
        links = []
        userId = note.getUserId(session['username'])
        postsId = note.CraftNoteLink(userId)
        for postId in postsId :
            link = "http://"+ hostname +"/view?key="+postId[2]
            links.append((link,postId[1]))
        return render_template('index.html', link_arr=links)
    return redirect(url_for('login'))

# authenication
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        action = request.form['action']
        print(username, password, action)
        if action == 'Log In':
            if auth.Authentication(username, password):
                session['username'] = username
                return redirect(url_for('index'))
        elif action == 'Register':
            if auth.Register(username, password):
                session['username'] = username
                return redirect(url_for('index'))
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/add', methods=['GET', 'POST'])
def add():
    if 'username' in session:
        if request.method == "GET":
            return render_template('add.html')
        else:
            userId = note.getUserId(session['username'])
            note.AddNote(userId, request.form['title'], request.form['note'])
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/view', methods=['GET'])
def view():
    if 'username' in session:
        key = request.args.get('key')
        if len(key) != 36:
            return render_template('view.html', note="ERROR: Invalid key")
        userId = note.getUserId(session['username'])
        if key is None:
            return render_template('view.html', note="ERROR: No key provided")
        content = note.GetNoteByKey(userId, key)
        if content:
            return render_template('view.html', note=content)
        else:
            return render_template('view.html', note="No such note")

@app.route('/logout', methods=['GET'])
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))


@app.route('/submit', methods=['GET'])
def submit():
    url = request.args.get('link')
    if url:
        bot.access(url)
        return render_template('submit.html', message="Success")
    return render_template('submit.html')

if __name__ == '__main__':
    app.run('0.0.0.0', port=80, debug=False)

