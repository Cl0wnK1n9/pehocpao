from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
import time
import os


# dit cu dung mozila
hostname = os.getenv('HOSTNAME','127.0.0.1')
admin_pass = os.getenv('ADMIN_PASS',"admin")
def access(url):
    # Initialize ChromeDriver with the Service
    # service = Service(executable_path='/usr/local/bin/geckodriver')
    # Start Chrome using the Service

    options = Options()
    # options.add_argument("--headless")

    driver = webdriver.Firefox(options=options)
    # Access web
    driver.get("http://"+ hostname)

    # Login
    username_field = driver.find_element(By.NAME, "username")
    password_field = driver.find_element(By.NAME, "password")
    submit_button = driver.find_element(By.ID, "login")

    username_field.send_keys('admin')
    password_field.send_keys(admin_pass)
    submit_button.click()

    driver.get(url)
    time.sleep(3)
    driver.quit()