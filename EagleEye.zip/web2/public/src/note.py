import  sqlite3
import uuid
import re 

def CraftNoteLink(userId):
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''SELECT * FROM notes WHERE userId = ?''', (userId,))
    result = c.fetchall()
    conn.close()
    return result

def getUserId(username):
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''SELECT id FROM users WHERE username = ?''', (username,))
    result = c.fetchone()
    conn.close()
    return result[0]

def AddNote(userId, title, note):
    uuidv4 = str(uuid.uuid4())
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''INSERT INTO notes (userId, title, key, note) VALUES (?, ?, ?, ?)''', (userId, title, uuidv4 , note))
    conn.commit()
    conn.close()

def GetNoteByKey(userId, key):
    conn = sqlite3.connect('auth.db')
    c = conn.cursor()
    c.execute('''SELECT note FROM notes WHERE userId = ? AND key LIKE ?''', (userId, key))
    result = c.fetchone()
    conn.close()
    if result:
        return XssFilter(result[0])
    else:
        return False
    
def XssFilter(input):
    input = input.replace('<script', '<dangerous')
    input = input.replace('script>', 'dangerous>')
    pattern = r'on[a-zA-Z]*'
    result = re.sub(pattern, 'onnothing', input)
    return result

