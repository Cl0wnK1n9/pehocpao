# run this script with bin/bash
# This script will build the docker image and run the container

docker build -t kacumatchalate .
docker run -p 9004:80 kacumatchalate 