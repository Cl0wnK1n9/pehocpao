<?php
    function login_page(){
        return file_get_contents("template/Login.html");
    }
    
    session_start();
    // check if user is logged in
    if(isset($_SESSION['user'])){
        // if user is logged in, redirect to home page
        header("Location: index.php");
    }
    if (isset($_POST['username']) && isset($_POST['password'])){
        // check if user is valid
        if($_POST['username'] == "admin" && $_POST['password'] == "admin"){
            // if user is valid, set session and redirect to home page
            $_SESSION['user'] = $_POST['username'];
            header("Location: index.php");
        }else{
            // if user is invalid, show error message
            echo "Invalid username or password";
            echo login_page();
        }
    }
    
    else{
        echo login_page();
    }
?>